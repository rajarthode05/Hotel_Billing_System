﻿namespace Hotel_Billing_System {
    
    
    public partial class hotelDataSet8 {
    }
}

