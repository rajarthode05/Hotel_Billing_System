﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;


namespace Hotel_Billing_System
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hotelDataSet3.Employee' table. You can move, or remove it, as needed.
         //   this.employeeTableAdapter.Fill(this.hotelDataSet3.Employee);
            // TODO: This line of code loads data into the 'hotelDataSet2.emp2' table. You can move, or remove it, as needed.
            // this.emp2TableAdapter1.Fill(this.hotelDataSet2.emp2);
            // TODO: This line of code loads data into the 'hotelDataSet1.emp2' table. You can move, or remove it, as needed.
          //  this.emp2TableAdapter.Fill(this.hotelDataSet1.emp2);
            int a;
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            con.Open();
            string st = "select max(id)from Employee";
            SqlCommand cmd = new SqlCommand(st, con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                string val = dr[0].ToString();
                if (val == "")
                {
                    txt_ID.Text = "111";
                }
                else
                {
                    a = 1 + Convert.ToInt16(dr[0].ToString());
                    txt_ID.Text = a.ToString();
                }
            }
            con.Close();

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_Name.Text == "")
            {
                MessageBox.Show("Enter All Details are required.....");
            }
            else
            {

                try
                {
                    SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter("insert into Employee (Name,mobileNo,Address)values('" + txt_Name.Text + "','" + txt_mob.Text + "','" + txt_Address.Text + "')", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    string s2 = "select * from Employee";
                    MessageBox.Show("Save Succesfully");
                    da.SelectCommand = new SqlCommand(s2, con);
                    da.Fill(dt);

                    BindingSource bs = new BindingSource();
                    bs.DataSource = dt;
                    dataGridView1.DataSource = bs;

                    txt_Name.Text = string.Empty;
                    txt_mob.Text = string.Empty;
                    txt_Address.Text = string.Empty;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txt_mob.Text == "")
            {
                MessageBox.Show("Enter All Details are required.....");
            }
            else
            {

                try
                {
                    SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter("update Employee set Name='" + txt_Name.Text + "',mobileNo='" + txt_mob.Text + "',Address='" + txt_Address.Text + "'where (id='" + txt_ID.Text + "')", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    MessageBox.Show("Update Succesfully");

                    string s2 = "select * from Employee";
                    da.SelectCommand = new SqlCommand(s2, con);
                    da.Fill(dt);

                    BindingSource bs = new BindingSource();
                    bs.DataSource = dt;
                    dataGridView1.DataSource = bs;

                    txt_Name.Text = string.Empty;
                    txt_mob.Text = string.Empty;
                    txt_Address.Text = string.Empty;



                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
                SqlDataAdapter da = new SqlDataAdapter("delete from Employee where (id='" + txt_ID.Text + "')", con);
                con.Open();
                DataTable dt = new DataTable();
                da.Fill(dt);
                //SqlDataReader dr;
                con.Close();

                MessageBox.Show("delete Succesfully");
                string s2 = "select * from employee";
                da.SelectCommand = new SqlCommand(s2, con);
                da.Fill(dt);

                BindingSource bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                txt_Name.Text = string.Empty;
                txt_mob.Text = string.Empty;
                txt_Address.Text = string.Empty;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from Employee where (id='" + txt_ID.Text + "')", con);
            SqlDataReader dr;
            try
            {
                con.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txt_Name.Text = dr.GetValue(1).ToString();
                    txt_mob.Text = dr.GetValue(2).ToString();
                    txt_Address.Text = dr.GetValue(3).ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
           

           

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
