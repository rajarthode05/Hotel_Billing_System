﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;

namespace Hotel_Billing_System
{
    public partial class Customer_Bill : Form
    {
        public static string bn = "";
        public Customer_Bill()
        {
            InitializeComponent();
          

        }
        public static int j;
        Label l = new Label();

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlCommand da = new SqlCommand("select * from menu where Product_code='" + txt_itemCode.Text + "'", con);
            SqlDataReader dr;

            try
            {
                con.Open();

                dr = da.ExecuteReader();

                while (dr.Read())
                {
                    txt_itemName.Text = dr.GetValue(1).ToString();
                    txt_Price.Text = dr.GetValue(4).ToString();

                }



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            int a = 0, b = 0;
            if (!string.IsNullOrWhiteSpace(txt_Price.Text))
            {

                a = int.Parse(txt_Price.Text);
            }
            if (!string.IsNullOrWhiteSpace(txt_qty.Text))
            {
                 b = int.Parse(txt_qty.Text);
            }
            txt_amt.Text = (a * b).ToString();
        }

        //public void fillPanel()
        //{
        //    int count = dataGridView1.Rows.Count;
        //    Label[] labels= new Label[count];

        //    for (int i = 0; i < count; i++)
        //    {
        //        labels[i] = new Label();
        //        labels[i].Name = "code" + i.ToString();
        //        labels[i].Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
        //      //  panel6.Controls.Add(labels[i]);
        //    }
        //}
        private void Form7_Load(object sender, EventArgs e)
        {
            Fillcombo();
            // TODO: This line of code loads data into the 'hotelDataSet4.customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.hotelDataSet4.customer);
            // TODO: This line of code loads data into the 'hotelDataSet3.bill_detail_1' table. You can move, or remove it, as needed.
            //this.bill_detail_1TableAdapter.Fill(this.hotelDataSet3.bill_detail_1);
            // TODO: This line of code loads data into the 'hotelDataSet2.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.hotelDataSet2.Employee);

      

            if (Tax_Discount.sc=="")
            {
                textBox8.Text = Convert.ToString("5");
                textBox10.Text = Convert.ToString("5");
                textBox9.Text = Convert.ToString("5");
                textBox11.Text = Convert.ToString("5");
                textBox3.Text = Convert.ToString("5");

            }
            else
            {

                textBox8.Text = Tax_Discount.sc;
                textBox10.Text = Tax_Discount.sg;
                textBox9.Text = Tax_Discount.cg;
                textBox11.Text = Tax_Discount.di;
                textBox3.Text = Tax_Discount.ig;

            }


            //textBox11.Text = Convert.ToString(textBox8.Text);
            //textBox10.Text = Convert.ToString(textBox10.Text);
            //textBox9.Text = Convert.ToString(textBox9.Text);
            //textBox8.Text = Convert.ToString(textBox11.Text);

           

           
            for ( j = 1; j <= 12; j++)
            {
                Label l = addlabel(j);
                flowLayoutPanel1.Controls.Add(l);
                l.DoubleClick += new System.EventHandler(this.doubleClick);
            }

            //SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            //SqlDataAdapter da = new SqlDataAdapter("select item_code,item_name,qty,price,amount from bill_detail_1 where bill_no='"+textBox2.Text+"'",con);
            //DataTable dt = new DataTable();
            //da.Fill(dt);
            //dataGridView1.DataSource = dt;
            getbillno();
           
        }
        public void getbillno()
        {

            int a;
            

            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            con.Open();
            string st = "select max(bill_no) from bill_detail_1";
            SqlCommand cmd = new SqlCommand(st, con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                string val = dr[0].ToString();
                if (val == "")
                {
                    textBox2.Text = "111";
                }
                else
                {
                    a = 1 + Convert.ToInt16(val);
                    textBox2.Text = a.ToString();
                }
            }
            con.Close();
        }
        void doubleClick(object sender,EventArgs e)
        {
            Label currentlabel = (Label)sender;
            textBox1.Text=(currentlabel.Text);
            //SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            //SqlDataAdapter da = new SqlDataAdapter("SELECT item_code,item_name,qty,price,amount from bill_detail_1 where selected_tab='" + textBox1.Text + "'", con);
            //DataTable dt = new DataTable();
            //da.Fill(dt);
            //dataGridView1.DataSource = dt;
           
        }
        private Label addlabel(int j)
        {
            //Label l = new Label();
            l = new Label();
            l.Name = "TB " + j.ToString();
            l.Text = "" + j.ToString();
            l.ForeColor=Color.White;
            l.BackColor=Color.Black;
            l.Font = new Font("Serif",12,FontStyle.Bold);
            l.Width=50;
            l.Height=50;
           // btn.Location=new Point(start,end);
            l.TextAlign = ContentAlignment.MiddleCenter;
            l.Margin = new Padding(5);
            return l;

        }

        //int c = 1;
        
        private void button16_Click(object sender, EventArgs e)
        {
           
            Label l = addlabel(j++);
            flowLayoutPanel1.Controls.Add(l);
            l.DoubleClick += new System.EventHandler(this.doubleClick);
            
          
           
        }
     
        private void button1_Click(object sender, EventArgs e)
        {
            
            //bool Found = false;
            //dataGridView1.AllowUserToAddRows = false;
            //if (dataGridView1.Rows.Count > 0)
            //{
            //    foreach (DataGridViewRow row in dataGridView1.Rows)
            //    {
            //        if (Convert.ToString(row.Cells[0].Value) == txt_itemName.Text && Convert.ToString(row.Cells[1].Value) == txt_Price.Text)
            //        {
            //            Found = true;
            //        }
            //    }
            //    if (!Found)
            //    {
            //        dataGridView1.Rows.Add(txt_itemCode.Text, txt_itemName.Text, txt_qty.Text, txt_Price.Text, txt_amt.Text, 1);
            //    }
            //}
            //else
            //{
            //    dataGridView1.Rows.Add(txt_itemCode.Text, txt_itemName.Text, txt_qty.Text, txt_Price.Text, txt_amt.Text, 1);
            //}
           
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");

            SqlDataAdapter da = new SqlDataAdapter("insert into bill_detail_1(item_code,item_name,qty,price,amount,selected_tab,bill_no)values('" + txt_itemCode.Text + "','" + txt_itemName.Text + "','" + txt_qty.Text + "','" + txt_Price.Text + "','" + txt_amt.Text + "','" + textBox1.Text + "','"+textBox2.Text+"')", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
           




            string sqlSelectAll = "SELECT item_code,item_name,qty,price,amount from bill_detail_1 where selected_tab='"+textBox1.Text+"' ";
            da.SelectCommand = new SqlCommand(sqlSelectAll, con);
            da.Fill(dt);

            BindingSource bSource = new BindingSource();
            bSource.DataSource = dt;


            dataGridView1.DataSource = bSource;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                row.Cells[dataGridView1.Columns["amount"].Index].Value = (Convert.ToDouble(row.Cells[dataGridView1.Columns["price"].Index].Value) * Convert.ToDouble(row.Cells[dataGridView1.Columns["qty"].Index].Value));
            }
            int sum1 = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                sum1 =sum1+ Convert.ToInt32(dataGridView1.Rows[i].Cells[4].Value);
            }
            txt_totalAmt.Text = sum1.ToString();

            txt_itemCode.Text = "";
            txt_itemName.Text = "";
            txt_Price.Text = "";
            txt_qty.Text = "";
           // txt_amt = ("").ToString();
            

            

            
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("delete from bill_detail_1 where selected_tab='" + textBox1.Text + "'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            MessageBox.Show("Successfully Deleted....");
            dataGridView1.Visible = true;

            string sqlSelectAll = "SELECT * from bill_detail_1";
            da.SelectCommand = new SqlCommand(sqlSelectAll, con);
            da.Fill(dt);

            BindingSource bSource = new BindingSource();
            bSource.DataSource = dt;


            dataGridView1.DataSource = bSource;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("SELECT item_code,item_name,qty,price,amount from bill_detail_1 where selected_tab='" + textBox1.Text + "'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            SqlCommand cmd = new SqlCommand("select * from bill_detail where select_table='" + textBox1.Text + "' ", con);
            SqlDataReader dr;

            con.Open();
            int c = 0;
            if (!string.IsNullOrWhiteSpace(textBox1.Text))
            {

                c = int.Parse(textBox1.Text);
            }
            dr = cmd.ExecuteReader();
           
            if (dr.HasRows)
            {
                while (dr.Read())
                {

                    textBox2.Text = dr.GetValue(1).ToString();
                    txt_totalAmt.Text = dr.GetValue(2).ToString();
                    comboBox1.Text = dr.GetValue(3).ToString();
                    textBox8.Text = dr.GetValue(4).ToString();
                    comboBox2.Text = dr.GetValue(5).ToString();
                    textBox9.Text = dr.GetValue(6).ToString();
                    comboBox3.Text = dr.GetValue(7).ToString();
                    textBox10.Text = dr.GetValue(8).ToString();
                    textBox11.Text = dr.GetValue(9).ToString();
                    textBox3.Text = dr.GetValue(10).ToString();
                    textBox12.Text = dr.GetValue(11).ToString();
                    textBox13.Text = dr.GetValue(12).ToString();
                    textBox14.Text = dr.GetValue(13).ToString();
                }
            }
            else
            {
                getbillno();
              //textBox2.Text = "";
                txt_totalAmt.Text = "";
                comboBox1.Text = "";
                textBox8.Text = "";
                comboBox2.Text = "";
                textBox9.Text = "";
                comboBox3.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                textBox3.Text = "";
                textBox12.Text = "";
                textBox13.Text = "";
                textBox14.Text = "";
            }
                
            
            con.Close();
            
            label2.Visible = false;
            txt_itemCode.Visible = false;
            label3.Visible = false;
            txt_itemName.Visible = false;
            label4.Visible = false;
            txt_Price.Visible = false;
            label5.Visible = false;
            txt_qty.Visible = false;
            label6.Visible = false;
            txt_amt.Visible = false;
            button1.Visible = false;
            button2.Visible = false;

           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text ="1";
        }

        
       
       

      

       

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            

           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
           //if(textBox1.Text==""||textBox2.Text==""||txt_itemCode.Text==""||txt_itemName.Text==""||txt_Price.Text==""||txt_qty.Text==""||txt_amt.Text==""||txt_totalAmt.Text==""||comboBox1.Text==""||comboBox2.Text==""||comboBox3.Text==""||textBox8.Text==""||textBox9.Text==""||textBox10.Text==""||textBox11.Text==""||textBox12.Text==""||textBox13.Text==""||textBox14.Text==""||textBox3.Text==""||textBox3.Text=="")
           //{
           //    MessageBox.Show("Please Enter all the details....");
           //}
           //else
           //{
            
                
                SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
                con.Open();
               
                    SqlCommand da = new SqlCommand("insert into bill_detail(select_table,bill_no,total_amount,cust_name,service_charge,waitor,cgst,payment,sgst,Discount,igst,Net_amount,Paid,remain)values('" + textBox1.Text + "','" + textBox2.Text + "','" + txt_totalAmt.Text + "','" + comboBox1.Text + "','" + textBox8.Text + "','" + comboBox2.Text + "','" + textBox9.Text + "','" + comboBox3.Text + "','" + textBox10.Text + "','" + textBox11.Text + "','"+textBox3.Text+"','" + textBox12.Text + "','" + textBox13.Text + "','" + textBox14.Text + "')", con);

                    da.ExecuteNonQuery();
                    
                
                MessageBox.Show("Saved Successfully....");
                
                bn = textBox2.Text;
                Form1 obj = new Form1();
                obj.Show();

                
                
            
           
           con.Close();
           
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
       
        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged_1(object sender, EventArgs e)
        {
            double net_amt = 0.0, paid = 0.0;

            if (!string.IsNullOrWhiteSpace(textBox12.Text))
            {

                net_amt = int.Parse(textBox12.Text);
            }
            if (!string.IsNullOrWhiteSpace(textBox13.Text))
            {

                paid = int.Parse(textBox13.Text);
            }
            
            textBox14.Text = (net_amt - paid).ToString();
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        
        void Fillcombo()
        {
            SqlConnection con=new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select  Name from Employee", con);
            
            
                con.Open();
                SqlDataReader dr=cmd.ExecuteReader();
                while(dr.Read())
                {
                    string str = (string)dr["Name"];
                    comboBox2.Items.Add(str);
                }
                dr.Close();
                con.Close();
          
        

        }
        private void button15_Click(object sender, EventArgs e)
        {
            j--;
            int i = 0;
            int a = j;
            for ( i = 0,a=j; i <= a; i++,a--)
            {
                foreach (Control l in flowLayoutPanel1.Controls)
                {


                    if (l.Name == "TB "+j.ToString())
                    {
                        flowLayoutPanel1.Controls.Remove(l);
                        break;
                    }

                }
            }
           

         
          
        }

        private void txtAdd_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button15_MouseClick(object sender, MouseEventArgs e)
        {
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txt_itemName_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter();
            con.Open();
            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand("select Product_Name from Menu  ", con);
            cmd.ExecuteNonQuery();
            dr = cmd.ExecuteReader();
            AutoCompleteStringCollection col = new AutoCompleteStringCollection();
            while (dr.Read())
            {
                col.Add(dr["Product_Name"].ToString());
            }
            txt_itemName.AutoCompleteCustomSource = col;
            con.Close();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            label2.Visible = true;
            txt_itemCode.Visible = true;
            label3.Visible = true;
            txt_itemName.Visible = true;
            label4.Visible = true;
            txt_Price.Visible = true;
            label5.Visible = true;
            txt_qty.Visible = true;
            label6.Visible = true;
            txt_amt.Visible = true;
            button1.Visible = true;
            button2.Visible = true;
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double totalAmount = Convert.ToDouble(txt_totalAmt.Text);

            double totalAmount1 = totalAmount * Convert.ToDouble(textBox8.Text) / 100 + totalAmount;
            double totalAmount2 = totalAmount * Convert.ToDouble(textBox9.Text) / 100 + totalAmount1;
            double totalAmount3 = totalAmount * Convert.ToDouble(textBox10.Text) / 100 + totalAmount2;
            double totalAmount4 = totalAmount * Convert.ToDouble(textBox3.Text) / 100 + totalAmount3;
            double totalAmount5 = totalAmount4 - totalAmount * Convert.ToDouble(textBox11.Text) / 100;

            double serv_charge = totalAmount * Convert.ToDouble(textBox8.Text) / 100;
            double cgst = totalAmount * Convert.ToDouble(textBox9.Text) / 100;
            double sgst = totalAmount * Convert.ToDouble(textBox10.Text) / 100;
            double igst = totalAmount * Convert.ToDouble(textBox3.Text) / 100;
            double discount = totalAmount * Convert.ToDouble(textBox11.Text) / 100;

            textBox8.Text = serv_charge.ToString();
            textBox9.Text = cgst.ToString();
            textBox10.Text = sgst.ToString();
            textBox3.Text = igst.ToString();
            textBox11.Text = discount.ToString();
            textBox12.Text = totalAmount5.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            con.Open();
            SqlCommand cmd2 = new SqlCommand("Delete from bill_detail where select_table='" + textBox1.Text + "'", con);

            SqlDataReader dr;

            dr = cmd2.ExecuteReader();
            MessageBox.Show("Deleted.....");
            while (dr.Read())
            {
            }
            con.Close();   
        }
       
    }
}
