﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;

namespace Hotel_Billing_System
{
    public partial class Login : Form
    {
        string s = ConfigurationManager.ConnectionStrings["str"].ConnectionString;
        public Login()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Registration obj = new Registration();
            obj.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(s);
            SqlCommand cmd = new SqlCommand("select * from reg where username='" + textBox1.Text + "'and pswd='" + textBox2.Text + "'", con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                
                Home obj = new Home();
                obj.Show();
            }
            else
            {
                MessageBox.Show("gari ja");
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Forgot obj = new Forgot();
            obj.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.BackColor = Color.Transparent;
            label2.BackColor = Color.Transparent;
            linkLabel1.BackColor = Color.Transparent;
            linkLabel2.BackColor = Color.Transparent;
            button1.BackColor = Color.Transparent;
        }
    }
}
