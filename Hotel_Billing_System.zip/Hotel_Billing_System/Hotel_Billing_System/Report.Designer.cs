﻿namespace Hotel_Billing_System
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.final_billBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hotelDataSet8 = new Hotel_Billing_System.hotelDataSet8();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.button1 = new System.Windows.Forms.Button();
            this.fillBy5ToolStrip = new System.Windows.Forms.ToolStrip();
            this.param1ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.param1ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillBy5ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.final_billTableAdapter = new Hotel_Billing_System.hotelDataSet8TableAdapters.final_billTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.hotelDataSet1 = new Hotel_Billing_System.hotelDataSet();
            this.fillBy7ToolStrip = new System.Windows.Forms.ToolStrip();
            this.param2ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.param2ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillBy7ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.fillBy8ToolStrip = new System.Windows.Forms.ToolStrip();
            this.param3ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.param3ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillBy8ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillBy9ToolStrip = new System.Windows.Forms.ToolStrip();
            this.param2ToolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.param2ToolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.param3ToolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.param3ToolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.fillBy9ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.button3 = new System.Windows.Forms.Button();
            this.fillBy10ToolStrip = new System.Windows.Forms.ToolStrip();
            this.param4ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.param4ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillBy10ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.textBox4 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.final_billBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet8)).BeginInit();
            this.fillBy5ToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet1)).BeginInit();
            this.fillBy7ToolStrip.SuspendLayout();
            this.fillBy8ToolStrip.SuspendLayout();
            this.fillBy9ToolStrip.SuspendLayout();
            this.fillBy10ToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // final_billBindingSource
            // 
            this.final_billBindingSource.DataMember = "final_bill";
            this.final_billBindingSource.DataSource = this.hotelDataSet8;
            // 
            // hotelDataSet8
            // 
            this.hotelDataSet8.DataSetName = "hotelDataSet8";
            this.hotelDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            reportDataSource2.Name = "DataSet1";
            reportDataSource2.Value = this.final_billBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Hotel_Billing_System.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(20, 422);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(1400, 517);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.FullPage;
            this.reportViewer1.ZoomPercent = 75;
            this.reportViewer1.AutoSizeChanged += new System.EventHandler(this.reportViewer1_AutoSizeChanged);
            this.reportViewer1.Load += new System.EventHandler(this.reportViewer1_Load);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(595, 56);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 31);
            this.button1.TabIndex = 2;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // fillBy5ToolStrip
            // 
            this.fillBy5ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param1ToolStripLabel,
            this.param1ToolStripTextBox,
            this.fillBy5ToolStripButton});
            this.fillBy5ToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillBy5ToolStrip.Name = "fillBy5ToolStrip";
            this.fillBy5ToolStrip.Size = new System.Drawing.Size(1157, 27);
            this.fillBy5ToolStrip.TabIndex = 5;
            this.fillBy5ToolStrip.Text = "fillBy5ToolStrip";
            this.fillBy5ToolStrip.Visible = false;
            // 
            // param1ToolStripLabel
            // 
            this.param1ToolStripLabel.Name = "param1ToolStripLabel";
            this.param1ToolStripLabel.Size = new System.Drawing.Size(61, 24);
            this.param1ToolStripLabel.Text = "Param1:";
            // 
            // param1ToolStripTextBox
            // 
            this.param1ToolStripTextBox.Name = "param1ToolStripTextBox";
            this.param1ToolStripTextBox.Size = new System.Drawing.Size(100, 27);
            // 
            // fillBy5ToolStripButton
            // 
            this.fillBy5ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy5ToolStripButton.Name = "fillBy5ToolStripButton";
            this.fillBy5ToolStripButton.Size = new System.Drawing.Size(56, 24);
            this.fillBy5ToolStripButton.Text = "FillBy5";
            this.fillBy5ToolStripButton.Click += new System.EventHandler(this.fillBy5ToolStripButton_Click);
            // 
            // final_billTableAdapter
            // 
            this.final_billTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 25);
            this.label1.TabIndex = 6;
            this.label1.Text = "From";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(237, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "Search by Name or Bill no";
            // 
            // textBox2
            // 
            this.textBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox2.Location = new System.Drawing.Point(284, 135);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(132, 22);
            this.textBox2.TabIndex = 8;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(437, 122);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 35);
            this.button2.TabIndex = 9;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // hotelDataSet1
            // 
            this.hotelDataSet1.DataSetName = "hotelDataSet";
            this.hotelDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fillBy7ToolStrip
            // 
            this.fillBy7ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param2ToolStripLabel,
            this.param2ToolStripTextBox,
            this.fillBy7ToolStripButton});
            this.fillBy7ToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillBy7ToolStrip.Name = "fillBy7ToolStrip";
            this.fillBy7ToolStrip.Size = new System.Drawing.Size(1157, 27);
            this.fillBy7ToolStrip.TabIndex = 13;
            this.fillBy7ToolStrip.Text = "fillBy7ToolStrip";
            this.fillBy7ToolStrip.Visible = false;
            // 
            // param2ToolStripLabel
            // 
            this.param2ToolStripLabel.Name = "param2ToolStripLabel";
            this.param2ToolStripLabel.Size = new System.Drawing.Size(61, 24);
            this.param2ToolStripLabel.Text = "Param2:";
            // 
            // param2ToolStripTextBox
            // 
            this.param2ToolStripTextBox.Name = "param2ToolStripTextBox";
            this.param2ToolStripTextBox.Size = new System.Drawing.Size(100, 27);
            // 
            // fillBy7ToolStripButton
            // 
            this.fillBy7ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy7ToolStripButton.Name = "fillBy7ToolStripButton";
            this.fillBy7ToolStripButton.Size = new System.Drawing.Size(56, 24);
            this.fillBy7ToolStripButton.Text = "FillBy7";
            this.fillBy7ToolStripButton.Click += new System.EventHandler(this.fillBy7ToolStripButton_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(135, 62);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(132, 22);
            this.dateTimePicker1.TabIndex = 15;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(789, 259);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 16;
            this.textBox1.Visible = false;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(353, 65);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker2.TabIndex = 17;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(789, 317);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 18;
            this.textBox3.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(296, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 25);
            this.label3.TabIndex = 19;
            this.label3.Text = "To";
            // 
            // fillBy8ToolStrip
            // 
            this.fillBy8ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param3ToolStripLabel,
            this.param3ToolStripTextBox,
            this.fillBy8ToolStripButton});
            this.fillBy8ToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillBy8ToolStrip.Name = "fillBy8ToolStrip";
            this.fillBy8ToolStrip.Size = new System.Drawing.Size(1157, 27);
            this.fillBy8ToolStrip.TabIndex = 20;
            this.fillBy8ToolStrip.Text = "fillBy8ToolStrip";
            this.fillBy8ToolStrip.Visible = false;
            // 
            // param3ToolStripLabel
            // 
            this.param3ToolStripLabel.Name = "param3ToolStripLabel";
            this.param3ToolStripLabel.Size = new System.Drawing.Size(61, 24);
            this.param3ToolStripLabel.Text = "Param3:";
            // 
            // param3ToolStripTextBox
            // 
            this.param3ToolStripTextBox.Name = "param3ToolStripTextBox";
            this.param3ToolStripTextBox.Size = new System.Drawing.Size(100, 27);
            // 
            // fillBy8ToolStripButton
            // 
            this.fillBy8ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy8ToolStripButton.Name = "fillBy8ToolStripButton";
            this.fillBy8ToolStripButton.Size = new System.Drawing.Size(56, 24);
            this.fillBy8ToolStripButton.Text = "FillBy8";
            this.fillBy8ToolStripButton.Click += new System.EventHandler(this.fillBy8ToolStripButton_Click);
            // 
            // fillBy9ToolStrip
            // 
            this.fillBy9ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param2ToolStripLabel1,
            this.param2ToolStripTextBox1,
            this.param3ToolStripLabel1,
            this.param3ToolStripTextBox1,
            this.fillBy9ToolStripButton});
            this.fillBy9ToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillBy9ToolStrip.Name = "fillBy9ToolStrip";
            this.fillBy9ToolStrip.Size = new System.Drawing.Size(1157, 27);
            this.fillBy9ToolStrip.TabIndex = 21;
            this.fillBy9ToolStrip.Text = "fillBy9ToolStrip";
            this.fillBy9ToolStrip.Visible = false;
            // 
            // param2ToolStripLabel1
            // 
            this.param2ToolStripLabel1.Name = "param2ToolStripLabel1";
            this.param2ToolStripLabel1.Size = new System.Drawing.Size(61, 24);
            this.param2ToolStripLabel1.Text = "Param2:";
            // 
            // param2ToolStripTextBox1
            // 
            this.param2ToolStripTextBox1.Name = "param2ToolStripTextBox1";
            this.param2ToolStripTextBox1.Size = new System.Drawing.Size(100, 27);
            // 
            // param3ToolStripLabel1
            // 
            this.param3ToolStripLabel1.Name = "param3ToolStripLabel1";
            this.param3ToolStripLabel1.Size = new System.Drawing.Size(61, 24);
            this.param3ToolStripLabel1.Text = "Param3:";
            // 
            // param3ToolStripTextBox1
            // 
            this.param3ToolStripTextBox1.Name = "param3ToolStripTextBox1";
            this.param3ToolStripTextBox1.Size = new System.Drawing.Size(100, 27);
            // 
            // fillBy9ToolStripButton
            // 
            this.fillBy9ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy9ToolStripButton.Name = "fillBy9ToolStripButton";
            this.fillBy9ToolStripButton.Size = new System.Drawing.Size(56, 24);
            this.fillBy9ToolStripButton.Text = "FillBy9";
            this.fillBy9ToolStripButton.Click += new System.EventHandler(this.fillBy9ToolStripButton_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(214, 209);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(202, 41);
            this.button3.TabIndex = 24;
            this.button3.Text = "Today\'s Report";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // fillBy10ToolStrip
            // 
            this.fillBy10ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param4ToolStripLabel,
            this.param4ToolStripTextBox,
            this.fillBy10ToolStripButton});
            this.fillBy10ToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillBy10ToolStrip.Name = "fillBy10ToolStrip";
            this.fillBy10ToolStrip.Size = new System.Drawing.Size(1452, 27);
            this.fillBy10ToolStrip.TabIndex = 25;
            this.fillBy10ToolStrip.Text = "fillBy10ToolStrip";
            this.fillBy10ToolStrip.Visible = false;
            this.fillBy10ToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.fillBy10ToolStrip_ItemClicked);
            // 
            // param4ToolStripLabel
            // 
            this.param4ToolStripLabel.Name = "param4ToolStripLabel";
            this.param4ToolStripLabel.Size = new System.Drawing.Size(61, 24);
            this.param4ToolStripLabel.Text = "Param4:";
            // 
            // param4ToolStripTextBox
            // 
            this.param4ToolStripTextBox.Name = "param4ToolStripTextBox";
            this.param4ToolStripTextBox.Size = new System.Drawing.Size(100, 27);
            // 
            // fillBy10ToolStripButton
            // 
            this.fillBy10ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy10ToolStripButton.Name = "fillBy10ToolStripButton";
            this.fillBy10ToolStripButton.Size = new System.Drawing.Size(64, 24);
            this.fillBy10ToolStripButton.Text = "FillBy10";
            this.fillBy10ToolStripButton.Click += new System.EventHandler(this.fillBy10ToolStripButton_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(789, 209);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 26;
            this.textBox4.Visible = false;
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1452, 959);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.fillBy10ToolStrip);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.fillBy8ToolStrip);
            this.Controls.Add(this.fillBy9ToolStrip);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.fillBy7ToolStrip);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fillBy5ToolStrip);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Report";
            this.Text = "Report";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form12_Load);
            ((System.ComponentModel.ISupportInitialize)(this.final_billBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet8)).EndInit();
            this.fillBy5ToolStrip.ResumeLayout(false);
            this.fillBy5ToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet1)).EndInit();
            this.fillBy7ToolStrip.ResumeLayout(false);
            this.fillBy7ToolStrip.PerformLayout();
            this.fillBy8ToolStrip.ResumeLayout(false);
            this.fillBy8ToolStrip.PerformLayout();
            this.fillBy9ToolStrip.ResumeLayout(false);
            this.fillBy9ToolStrip.PerformLayout();
            this.fillBy10ToolStrip.ResumeLayout(false);
            this.fillBy10ToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource final_billBindingSource;
        private hotelDataSet8 hotelDataSet8;
        private hotelDataSet8TableAdapters.final_billTableAdapter final_billTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStrip fillBy5ToolStrip;
        private System.Windows.Forms.ToolStripLabel param1ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox param1ToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillBy5ToolStripButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button2;
        private hotelDataSet hotelDataSet1;
        private System.Windows.Forms.ToolStrip fillBy7ToolStrip;
        private System.Windows.Forms.ToolStripLabel param2ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox param2ToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillBy7ToolStripButton;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStrip fillBy8ToolStrip;
        private System.Windows.Forms.ToolStripLabel param3ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox param3ToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillBy8ToolStripButton;
        private System.Windows.Forms.ToolStrip fillBy9ToolStrip;
        private System.Windows.Forms.ToolStripLabel param2ToolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox param2ToolStripTextBox1;
        private System.Windows.Forms.ToolStripLabel param3ToolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox param3ToolStripTextBox1;
        private System.Windows.Forms.ToolStripButton fillBy9ToolStripButton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolStrip fillBy10ToolStrip;
        private System.Windows.Forms.ToolStripLabel param4ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox param4ToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillBy10ToolStripButton;
        private System.Windows.Forms.TextBox textBox4;
    }
}