﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.Reporting.WinForms;

namespace Hotel_Billing_System
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }
        
        private void Form12_Load(object sender, EventArgs e)
        {

          
            // TODO: This line of code loads data into the 'hotelDataSet8.final_bill' table. You can move, or remove it, as needed.
            this.final_billTableAdapter.Fill(this.hotelDataSet8.final_bill);
            this.reportViewer1.RefreshReport();
            DateTime d = new DateTime();
            d = DateTime.Now;

            textBox4.Text = d.ToString("dd-MM-yyyy");
           
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {
            
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string date1=dateTimePicker1.Value.ToShortDateString();
                string date2 = dateTimePicker2.Value.ToShortDateString();
                textBox1.Text = date1;
                textBox3.Text = date2;
                this.final_billTableAdapter.FillBy5(this.hotelDataSet8.final_bill,textBox1.Text );
                this.final_billTableAdapter.FillBy8(this.hotelDataSet8.final_bill, textBox3.Text);
                this.final_billTableAdapter.FillBy9(this.hotelDataSet8.final_bill, textBox1.Text, textBox3.Text);
                this.reportViewer1.RefreshReport();
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
           
        }

      


        private void fillBy4ToolStripButton_Click(object sender, EventArgs e)
        {

        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void fillBy5ToolStripButton_Click(object sender, EventArgs e)
        {
           

        }

       
        private void fillBy6ToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void fillBy7ToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
         
            try
            {
                this.final_billTableAdapter.FillBy7(this.hotelDataSet8.final_bill, textBox2.Text);
                this.reportViewer1.RefreshReport();
               
               
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

       

       

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void fillBy8ToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void fillBy9ToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                this.final_billTableAdapter.FillBy10(this.hotelDataSet8.final_bill, textBox4.Text);
                this.reportViewer1.RefreshReport();
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void fillBy10ToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da=new SqlDataAdapter();
            con.Open();
            SqlDataReader dr;
            SqlCommand cmd=new SqlCommand("select name from final_bill  ",con);
            cmd.ExecuteNonQuery();
            dr=cmd.ExecuteReader();
            AutoCompleteStringCollection col = new AutoCompleteStringCollection();
            while (dr.Read())
            {
                col.Add(dr.GetString(0));
            }
            textBox2.AutoCompleteCustomSource = col;
            con.Close();
        }

        private void reportViewer1_AutoSizeChanged(object sender, EventArgs e)
        {
           
        }

        private void fillBy10ToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

       

       
    }
}
