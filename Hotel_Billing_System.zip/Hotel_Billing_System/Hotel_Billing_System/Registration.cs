﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;

namespace Hotel_Billing_System
{
    public partial class Registration : Form
    {
        string s=ConfigurationManager.ConnectionStrings["str"].ConnectionString;
        public Registration()
        {
            InitializeComponent();
        }
       
        
        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection con=new SqlConnection (s);
            SqlCommand cmd = new SqlCommand("Insert into reg (username,pswd,city,mob,email)values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox4.Text + "','" + textBox3.Text + "','"+textBox5.Text+"')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Saved succesfully");
            con.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //pictureBox1.BackColor = Color.Transparent;
           

            label1.BackColor = Color.Transparent;
            label2.BackColor = Color.Transparent;
            label3.BackColor = Color.Transparent;
            label4.BackColor = Color.Transparent;
            label5.BackColor = Color.Transparent;
            label6.BackColor = Color.Transparent;

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}
