﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;

namespace Hotel_Billing_System
{
    public partial class Product : Form
    {
        int a;
        public Product()
        {
            InitializeComponent();
        }
        //id is auto increment 
        private void Form5_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            con.Open();
            string st = "select max(Product_Code) from menu";
            SqlCommand cmd = new SqlCommand(st, con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                string val = dr[0].ToString();
                if (val == "")
                {
                    textBox1.Text = "111";
                }
                else
                {
                    a = 1 + Convert.ToInt16(dr[0].ToString());
                    textBox1.Text = a.ToString();
                }
            }
            con.Close();
            
            
            
            
            // TODO: This line of code loads data into the 'hotelDataSet.Menu' table. You can move, or remove it, as needed.
          // this.menuTableAdapter.Fill(this.hotelDataSet.Menu);


        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string str = "  ";
            //if (checkBox1.Checked)
            //{
            //    str = str  + checkBox1.Text;
            //}
            //if (checkBox2.Checked)
            //{
            //    str = str  + checkBox2.Text;
            //}
            string str1 = "";
            if (checkBox3.Checked)
            {
                str1 = str1 + checkBox3.Text;
            }
            if (checkBox4.Checked)
            {
                str1 = str1 + checkBox4.Text;
            }
            if (checkBox5.Checked)
            {
                str1 = str1 + checkBox5.Text;
            }
            if (checkBox6.Checked)
            {
                str1 = str1  + checkBox6.Text;

            }

            if (checkBox7.Checked)
            {
                str1 = str1  + checkBox7.Text;
            }
            if (checkBox8.Checked)
            {
                str1 = str1  + checkBox8.Text;
            }
            if (checkBox9.Checked)
            {
                str1 = str1 + checkBox9.Text;
            }
               // str = str.TrimStart(',');

                SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
                SqlDataAdapter da = new SqlDataAdapter("insert into Menu(Product_name,Product_cat,Product_subcat,Price)values('" + textBox3.Text + "','" +comboBox1.Text + "','" + str1 + "','" + textBox2.Text + "')", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                MessageBox.Show("Saved successfully");
                
                //dataGridView1.DataSource = bs;
                


               
                string sqlSelectAll = "SELECT * from Menu";
                da.SelectCommand = new SqlCommand(sqlSelectAll, con);
                da.Fill(dt);

                BindingSource bSource = new BindingSource();
                bSource.DataSource = dt;


                dataGridView1.DataSource = bSource;

                dataGridView1.Visible = true;
                con.Close();
                
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btn_veg_Click(object sender, EventArgs e)
        {
           
        }

        private void btn_non_veg_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("update menu set price='"+textBox2.Text+"'where (Product_Code='"+textBox1.Text+"')", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            MessageBox.Show("Successfully Updated ....");
            dataGridView1.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("delete from menu where Product_Code='"+textBox1.Text+"'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            MessageBox.Show("Successfully Deleted....");
            dataGridView1.Visible = true;
        }
        
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
        
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlCommand da = new SqlCommand("select * from menu where Product_code='" + textBox4.Text + "'", con);
            SqlDataReader dr;
           
            try
            {
                con.Open();
               
                dr = da.ExecuteReader();
                
                    while (dr.Read())
                    {
                        textBox3.Text = dr.GetValue(1).ToString();
                        textBox2.Text = dr.GetValue(4).ToString();

                    }
                
                
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void checkBox1_BindingContextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckStateChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            //checkBox2.Checked = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_veg_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("select product_code,product_name,price from menu where Product_cat='veg'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Visible = true;
        }

        private void btn_non_veg_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("select product_code,product_name,price from menu where Product_Cat='non-veg';", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Visible = true;
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("delete from menu where Product_Code='" + textBox1.Text + "'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            MessageBox.Show("Successfully Deleted....");
            dataGridView1.Visible = true;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("update menu set price='" + textBox2.Text + "'where (Product_Code='" + textBox1.Text + "')", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            MessageBox.Show("Successfully Updated ....");
            dataGridView1.Visible = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //string str = "  ";
            //if (checkBox1.Checked)
            //{
            //    str = str + "," + checkBox1.Text;
            //}
            //if (checkBox2.Checked)
            //{
            //    str = str + "," + checkBox2.Text;
            //}
            string str1 = "";
            if (checkBox3.Checked)
            {
                str1 = str1 + "," + checkBox3.Text;
            }
            if (checkBox4.Checked)
            {
                str1 = str1 + "," + checkBox4.Text;
            }
            if (checkBox5.Checked)
            {
                str1 = str1 + "," + checkBox5.Text;
            }
            if (checkBox6.Checked)
            {
                str1 = str1 + "," + checkBox6.Text;

            }

            if (checkBox7.Checked)
            {
                str1 = str1 + "," + checkBox7.Text;
            }
            if (checkBox8.Checked)
            {
                str1 = str1 + "," + checkBox8.Text;
            }
            if (checkBox9.Checked)
            {
                str1 = str1 + "," + checkBox9.Text;
            }
           // str = str.TrimStart(',');

            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("insert into Menu(Product_name,Product_cat,Product_subcat,Price)values('" + textBox3.Text + "','" + comboBox1.Text + "','" + str1 + "','" + textBox2.Text + "')", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            MessageBox.Show("Saved successfully");

            //dataGridView1.DataSource = bs;




            string sqlSelectAll = "SELECT * from Menu";
            da.SelectCommand = new SqlCommand(sqlSelectAll, con);
            da.Fill(dt);

            BindingSource bSource = new BindingSource();
            bSource.DataSource = dt;


            dataGridView1.DataSource = bSource;

            dataGridView1.Visible = true;
            con.Close();
        }

        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlCommand da = new SqlCommand("select * from menu where Product_code='" + textBox4.Text + "'", con);
            SqlDataReader dr;

            try
            {
                con.Open();

                dr = da.ExecuteReader();

                while (dr.Read())
                {
                    textBox3.Text = dr.GetValue(1).ToString();
                    textBox2.Text = dr.GetValue(4).ToString();

                }



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Form5_Load_1(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            con.Open();
            string st = "select max(Product_Code) from menu";
            SqlCommand cmd = new SqlCommand(st, con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                
                string val = dr[0].ToString();
                if (val == "")
                {
                    textBox1.Text = "111";
                }
                else
                {
                    a = 1 + Convert.ToInt16(dr[0].ToString());
                    textBox1.Text = a.ToString();
                }
            }
            con.Close();
            
        }

        private void groupBox1_Enter_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
                SqlDataAdapter da = new SqlDataAdapter();
                con.Open();
                SqlDataReader dr;
                SqlCommand cmd = new SqlCommand("select Product_Name from Menu  ", con);
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                AutoCompleteStringCollection col = new AutoCompleteStringCollection();
                while (dr.Read())
                {
                    col.Add(dr["Product_Name"].ToString());
                }

                textBox3.AutoCompleteCustomSource = col;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
           
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
        //    if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
        //    {
        //        dataGridView1.CurrentRow.Selected = true;
        //        textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["Product_Code"].FormattedValue.ToString();
        //        textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["Product_Name"].FormattedValue.ToString();
        //        textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["Price"].FormattedValue.ToString();
               
        //    }
            if (MessageBox.Show("Are you sure to delete?", "Delete Document", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {

                    dataGridView1.CurrentRow.Selected = true;
                    string id = dataGridView1.Rows[e.RowIndex].Cells["Product_Code"].FormattedValue.ToString();
                    SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
                    SqlDataAdapter da = new SqlDataAdapter("delete from menu where Product_Code='" + id + "'", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                    MessageBox.Show("Successfully Deleted....");
                    dataGridView1.Visible = true;


                }

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

