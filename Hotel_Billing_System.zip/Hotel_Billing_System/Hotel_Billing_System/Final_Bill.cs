﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;

namespace Hotel_Billing_System
{
    public partial class Final_Bill : Form
    {
        public static string bn_1="";
        public Final_Bill()
        {
            InitializeComponent();

        }

        public void fillPanel()
        {
            int count = dataGridView1.Rows.Count;
            Label[] labels = new Label[count];

            for (int i = 0; i < count; i++)
            {
                labels[i] = new Label();
                labels[i].Name = "code" + i.ToString();
                labels[i].Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                panel6.Controls.Add(labels[i]);
                labels[i].Location = new Point(15, 15);
                if (i > 0)
                {
                    labels[i].Location = new Point(15, labels[i - 1].Location.Y+labels[i-1].Height);

                }
                labels[i] = new Label();
                labels[i].Name = "name" + i.ToString();
                labels[i].Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                panel7.Controls.Add(labels[i]);
                labels[i].Location = new Point(15, 15);
                if (i > 0)
                {
                    labels[i].Location = new Point(15, labels[i - 1].Location.Y + labels[i - 1].Height);

                }
                labels[i] = new Label();
                labels[i].Name = "qty" + i.ToString();
                labels[i].Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                panel8.Controls.Add(labels[i]);
                labels[i].Location = new Point(15, 15);
                if (i > 0)
                {
                    labels[i].Location = new Point(15, labels[i - 1].Location.Y + labels[i - 1].Height);

                }
                labels[i] = new Label();
                labels[i].Name = "price" + i.ToString();
                labels[i].Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                panel9.Controls.Add(labels[i]);
                labels[i].Location = new Point(15, 15);
                if (i > 0)
                {
                    labels[i].Location = new Point(15, labels[i - 1].Location.Y + labels[i - 1].Height);

                }
                labels[i] = new Label();
                labels[i].Name = "amount" + i.ToString();
                labels[i].Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
                panel11.Controls.Add(labels[i]);
                labels[i].Location = new Point(15, 15);
                if (i > 0)
                {
                    labels[i].Location = new Point(15, labels[i - 1].Location.Y + labels[i - 1].Height);

                }
            }
        }
        private void Form11_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hotelDataSet5.bill_detail_1' table. You can move, or remove it, as needed.
            this.bill_detail_1TableAdapter.Fill(this.hotelDataSet5.bill_detail_1);
            bn_1 = Customer_Bill.bn;
           label18.Text = bn_1;

            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("select item_code,item_name,qty,price,amount from bill_detail_1 where bill_no='"+label18.Text+"'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            fillPanel();
        }

        private void panel10_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            DateTime d = new DateTime();
            d = DateTime.Now;

            label19.Text = d.ToString("dd-MM-yyyy");
            label20.Text = d.ToString("HH:mm:ss");

            bn_1 = Customer_Bill.bn;
            label18.Text = bn_1;

            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select * from bill_detail where bill_no='"+label18.Text+"' ", con);
            SqlDataReader dr;

            con.Open();

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                
                label16.Text = dr.GetValue(3).ToString();
                label21.Text = dr.GetValue(2).ToString();
                label22.Text = dr.GetValue(4).ToString();
                label23.Text = dr.GetValue(6).ToString();
                label24.Text = dr.GetValue(8).ToString();
                label25.Text = dr.GetValue(10).ToString();
            }
            dr.Close();
          
            con.Close();

            //string str1 = "SELECT item_name,qty,price,amount,bill_no from bill_detail_1 where bill_no='" + label18.Text + "'";
            //SqlCommand cmd1 = new SqlCommand("SELECT item_name,qty,price,amount from bill_detail_1 where bill_no='" + label18.Text + "'",con);
            //SqlDataReader dr1;
            //con.Open();

            //dr1 = cmd1.ExecuteReader();

            
            //    while (dr1.Read())
            //    {
            //        //label26.Text = dr1.GetValue(1).ToString();
            //        //label27.Text = dr1.GetValue(2).ToString();
            //        //label28.Text = dr1.GetValue(3).ToString();
            //        //label29.Text = dr1.GetValue(4).ToString();
            //    }
            
            //con.Close();
        }

        private void panel13_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        Bitmap bmp;

        private void button1_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            bmp = new Bitmap(this.Size.Width, this.Size.Height, g);
            Graphics mg = Graphics.FromImage(bmp);

            button1.Visible = false;

            mg.CopyFromScreen(this.Location.X, this.Location.Y, 22, 12, this.Size);
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(bmp, 0, 0);
        }

        //private void Form11_Activated(object sender, EventArgs e)
        //{
        //  //  button1.Visible = true;
        //}

        
       /* private void button2_Click(object sender, EventArgs e)
        {
            string str = "  ";
            int i;
            for(i=0;i<dataGridView1.Rows.Count;i++)
            {
            foreach (DataGridViewRow row in dataGridView1.Rows)
              {
               if (dataGridView1.Rows[i].Cells[0].Value.ToString()!=null)
            {
                str = str + "," + dataGridView1.Rows[i].Cells[0].Value.ToString();
            }
               if (dataGridView1.Rows[i].Cells[1].Value.ToString() != null)
            {
                str = str + "," + dataGridView1.Rows[i].Cells[1].Value.ToString();
            }
               if (dataGridView1.Rows[i].Cells[2].Value.ToString() != null)
               {
                   str = str + "," + dataGridView1.Rows[i].Cells[2].Value.ToString();
               }
               if (dataGridView1.Rows[i].Cells[3].Value.ToString() != null)
               {
                   str = str + "," + dataGridView1.Rows[i].Cells[3].Value.ToString();
               }
               if (dataGridView1.Rows[i].Cells[4].Value.ToString() != null)
               {
                   str = str + "," + dataGridView1.Rows[i].Cells[4].Value.ToString();
               }
               if (dataGridView1.Rows[i].Cells[5].Value.ToString() != null)
               {
                   str = str + "," + dataGridView1.Rows[i].Cells[5].Value.ToString();
               }
               if (dataGridView1.Rows[i].Cells[6].Value.ToString() != null)
               {
                   str = str + "," + dataGridView1.Rows[i].Cells[6].Value.ToString();
               }
             }
            }
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("insert into final_bill(name,info,bill_no,date_1,time_1,amount,service_charge,cgst,sgst,net_amount)values('" + label16.Text + "','" + str + "','" + label18.Text + "','" + label19.Text + "','" + label20.Text + "','" + label21.Text + "','" + label22.Text + "','" + label23.Text + "','" + label24.Text + "','" + label25.Text + "')", con);
        }*/

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel15_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string str = "  ";
            int i;
            for (i = 0; i < dataGridView1.Rows.Count; i++)
            {
                
                    if (dataGridView1.Rows[i].Cells[0].Value.ToString() != null)
                    {
                        str = str + "," + dataGridView1.Rows[i].Cells[0].Value.ToString();
                    }
                    if (dataGridView1.Rows[i].Cells[1].Value.ToString() != null)
                    {
                        str = str + "," + dataGridView1.Rows[i].Cells[1].Value.ToString();
                    }
                    if (dataGridView1.Rows[i].Cells[2].Value.ToString() != null)
                    {
                        str = str + "," + dataGridView1.Rows[i].Cells[2].Value.ToString();
                    }
                    if (dataGridView1.Rows[i].Cells[3].Value.ToString() != null)
                    {
                        str = str + "," + dataGridView1.Rows[i].Cells[3].Value.ToString();
                    }
                    if (dataGridView1.Rows[i].Cells[4].Value.ToString() != null)
                    {
                        str = str + "," + dataGridView1.Rows[i].Cells[4].Value.ToString();
                    }
                    //if (dataGridView1.Rows[i].Cells[5].Value.ToString() != null)
                    //{
                    //    str = str + "," + dataGridView1.Rows[i].Cells[5].Value.ToString();
                    //}
                    //if (dataGridView1.Rows[i].Cells[6].Value.ToString() != null)
                    //{
                    //    str = str + "," + dataGridView1.Rows[i].Cells[6].Value.ToString();
                    //}
                
            }
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into final_bill(name,info,bill_no,date_1,time_1,amount,service_charge,cgst,sgst,net_amount)values('" + label16.Text + "','" + str + "','" + label18.Text + "','" + label19.Text + "','" + label20.Text + "','" + label21.Text + "','" + label22.Text + "','" + label23.Text + "','" + label24.Text + "','" + label25.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void panel12_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel14_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel20_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel10_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void panel15_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void panel13_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void lineShape2_Click(object sender, EventArgs e)
        {

        }
    }
}
