﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;

namespace Hotel_Billing_System
{
    public partial class Forgot : Form
    {
        string s = ConfigurationManager.ConnectionStrings["str"].ConnectionString;
        public Forgot()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(s);
            if (textBox1.Text == textBox2.Text )
            {

                SqlCommand cmd = new SqlCommand("update reg set pswd='" + textBox1.Text + "' where username='" + textBox3.Text + "'", con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Saved");
            }
            else
            {
                
                MessageBox.Show("Retype your password");
            }
            
            
           
            con.Close();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
