﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Billing_System
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void projectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forgot obj = new Forgot();
            obj.Show();
        }

        private void productMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Product obj = new Product();
            obj.Show();
        }

        private void customerMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
        }

        private void customerBillToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Customer_Bill obj = new Customer_Bill();
            obj.Show();
        }

        private void taxAndDiscountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tax_Discount obj = new Tax_Discount();
            obj.Show();
        }

        private void employeeMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.Show();
        }

        private void reportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report obj = new Report();
            obj.Show();
        }
    }
}
