﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;

namespace Hotel_Billing_System
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }
        //id auto increment
        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string str = "  ";
            if (checkBox1.Checked)
            {
                str = str + "," + checkBox1.Text;
            }
            if (checkBox2.Checked)
            {
                str = str + "," + checkBox2.Text;
            }
            if (checkBox3.Checked)
            {
                str = str + "," + checkBox3.Text;
            }

            str = str.TrimStart(',');

            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into customer(Custom_Id,First_Name,Last_Name,Street_Address,Street_Address_Line2,City,State_Province,Postal_Code,Country,Area_Code,Phone_No,Email,Info,Feedback,Suggestion,Recommend)values('" + textBox11.Text + "','" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + comboBox1.Text + "','" + textBox12.Text + "','" + textBox13.Text + "','" + textBox8.Text + "','" + comboBox2.Text + "','" + textBox9.Text + "','" + textBox10.Text + "','" + str + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Saved successfully");

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            comboBox1.Text="";
            textBox12.Text="";
            textBox13.Text="";
            textBox8.Text="";
            comboBox2.Text="";
            textBox9.Text="";
            textBox10.Text="";
            checkBox1.Text="";
            checkBox2.Text="";
            checkBox3.Text="";
            






            con.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            con.Open();
            string str = "  ";
            if (checkBox1.Checked)
            {
                str = str + "," + checkBox1.Text;
            }
            if (checkBox2.Checked)
            {
                str = str + "," + checkBox2.Text;
            }
            if (checkBox3.Checked)
            {
                str = str + "," + checkBox3.Text;
            }

            str = str.TrimStart(',');
            SqlDataAdapter da = new SqlDataAdapter("update customer set First_Name='" + textBox1.Text + "',Last_Name='" + textBox2.Text + "',Street_Address='" + textBox3.Text + "',Street_Address_Line2='" + textBox4.Text + "',City='" + textBox5.Text + "',State_Province='" + textBox6.Text + "',Postal_Code='" + textBox7.Text + "',Country='" + comboBox1.Text + "',Area_Code='" + textBox9.Text + "',Phone_No='" + textBox8.Text + "',Email='" + textBox10.Text + "',Info='" + comboBox2.Text + "',Feedback='" + textBox11.Text + "',Suggestion='" + textBox12.Text + "',Recommend='" + str + "' where (Custom_Id='" + textBox11.Text + "')", con);
            
            
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            MessageBox.Show("Successfully Updated ....");
            dataGridView1.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
             SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from customer where Custom_Id='"+textBox11.Text+"'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Deleted....");
            con.Close();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hotelDataSet1.Menu' table. You can move, or remove it, as needed.
            this.menuTableAdapter.Fill(this.hotelDataSet1.Menu);
            int a;
            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            con.Open();
            string st = "select max(Custom_Id) from customer";
            SqlCommand cmd = new SqlCommand(st, con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                string val = dr[0].ToString();
                if (val == "")
                {
                    textBox11.Text = "1";
                }
                else
                {
                    a = 1 + Convert.ToInt16(dr[0].ToString());
                    textBox11.Text = a.ToString();
                }
            }
            con.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source=RAJAT\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("select * from customer where Custom_Id='"+textBox11.Text+"'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView2.DataSource = dt;
            dataGridView2.Visible = true;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
           
        }

        private void label15_Click(object sender, EventArgs e)
        {

        }
    }
}

