﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Billing_System
{
    public partial class Tax_Discount : Form
    {
        public static string sc = "";
        public static string sg = "";
        public static string cg = "";
        public static string di = "";
        public static string ig = "";
        public Tax_Discount()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sc = textBox1.Text;
            sg = textBox2.Text;
            cg = textBox3.Text;
            di = textBox4.Text;
            ig = textBox5.Text;

            
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
